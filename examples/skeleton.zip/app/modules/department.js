(function(Department) {

  Department.Model = Backbone.Model.extend({ /* ... */ });
  Department.Collection = Backbone.Collection.extend({ /* ... */ });
  Department.Router = Backbone.Router.extend({ /* ... */ });

  // This will fetch the tutorial template and render it.
  Department.Views.Tutorial = Backbone.View.extend({
    template: "app/templates/department.html",

    render: function(done) {
      var view = this;

      // Fetch the template, render it to the View element and call done.
      namespace.fetchTemplate(this.template, function(tmpl) {
        view.el.innerHTML = tmpl();

        done(view.el);
      });
    }
  });

})(namespace.module("department"));
