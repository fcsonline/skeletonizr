var express  = require("express");
var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/skeleton');

var Schema = mongoose.Schema, ObjectId = Schema.ObjectId;


var CustomerSchema = new Schema({
    id            : ObjectId
  , title         : String
  , description   : String
  , date          : Date
});

var EmployeeSchema = new Schema({
    id            : ObjectId
  , title         : String
  , description   : String
  , date          : Date
});

var DepartmentSchema = new Schema({
    id            : ObjectId
  , title         : String
  , description   : String
  , date          : Date
});


// The mongo collections

var Customer = mongoose.model('Customer', CustomerSchema);

var Employee = mongoose.model('Employee', EmployeeSchema);

var Department = mongoose.model('Department', DepartmentSchema);


function defaultSaveMongo(err){
  // saving is asynchronous
  if(err) console.log("Something went wrong while saving the thing");
  else console.log("Thing was successfully saved");
};

// Creating some instances

var customer1 = new Customer({title:'hello world'});
var customer2 = new Customer({title:'hello world'});
var customer3 = new Customer({title:'hello world'});

customer1.save(defaultSaveMongo);
customer2.save(defaultSaveMongo);
customer3.save(defaultSaveMongo);

var employee1 = new Employee({title:'hello world'});
var employee2 = new Employee({title:'hello world'});
var employee3 = new Employee({title:'hello world'});

employee1.save(defaultSaveMongo);
employee2.save(defaultSaveMongo);
employee3.save(defaultSaveMongo);

var department1 = new Department({title:'hello world'});
var department2 = new Department({title:'hello world'});
var department3 = new Department({title:'hello world'});

department1.save(defaultSaveMongo);
department2.save(defaultSaveMongo);
department3.save(defaultSaveMongo);


var app = express.createServer();

app.configure(function() {

    // Standard express setup
    app.use(express.methodOverride());
    app.use(express.bodyParser());
    app.use(app.router);
    app.use(express.static(__dirname + '/public'));

    // Use the Jade template engine
    app.set('view engine', 'jade');
    app.set('view options', { layout: false });

});

app.get("/", function(req, resp) {
    resp.render("home", {
        pageTitle: "Ticker Analysis Sample"
    });
});


// List for customer entity
app.get("/customer/", function(req, resp) {
    console.log('Reading list of "customer" entities ')
    var Customer = mongoose.model("Customer", "customer");

    Customer.find({}, [], {}, function(err, docs) {
        console.log('Readed "customer" ' + docs);
        docs = docs.map(function(d) {
          return { title: d.title, id: d._id };
        });

        resp.send(JSON.stringify(docs));
    });
});

// Detail for customer entity
app.get("/customer/:id", function(req, resp) {
    console.log('Reading entity "customer" with id ' + req.params.id)
    var Customer = mongoose.model("Customer", "customer");
    Customer.findById(req.params.id, function(err, data) {
        if(err) {
            // Handle error
        }
        resp.send(JSON.stringify(data));
    });
});

// List for employee entity
app.get("/employee/", function(req, resp) {
    console.log('Reading list of "employee" entities ')
    var Employee = mongoose.model("Employee", "employee");

    Employee.find({}, [], {}, function(err, docs) {
        console.log('Readed "employee" ' + docs);
        docs = docs.map(function(d) {
          return { title: d.title, id: d._id };
        });

        resp.send(JSON.stringify(docs));
    });
});

// Detail for employee entity
app.get("/employee/:id", function(req, resp) {
    console.log('Reading entity "employee" with id ' + req.params.id)
    var Employee = mongoose.model("Employee", "employee");
    Employee.findById(req.params.id, function(err, data) {
        if(err) {
            // Handle error
        }
        resp.send(JSON.stringify(data));
    });
});

// List for department entity
app.get("/department/", function(req, resp) {
    console.log('Reading list of "department" entities ')
    var Department = mongoose.model("Department", "department");

    Department.find({}, [], {}, function(err, docs) {
        console.log('Readed "department" ' + docs);
        docs = docs.map(function(d) {
          return { title: d.title, id: d._id };
        });

        resp.send(JSON.stringify(docs));
    });
});

// Detail for department entity
app.get("/department/:id", function(req, resp) {
    console.log('Reading entity "department" with id ' + req.params.id)
    var Department = mongoose.model("Department", "department");
    Department.findById(req.params.id, function(err, data) {
        if(err) {
            // Handle error
        }
        resp.send(JSON.stringify(data));
    });
});


app.listen(9000);
