(function(Customer) {

  Customer.Model = Backbone.Model.extend({ /* ... */ });
  Customer.Collection = Backbone.Collection.extend({ /* ... */ });
  Customer.Router = Backbone.Router.extend({ /* ... */ });

  // This will fetch the tutorial template and render it.
  Customer.Views.Tutorial = Backbone.View.extend({
    template: "app/templates/customer.html",

    render: function(done) {
      var view = this;

      // Fetch the template, render it to the View element and call done.
      namespace.fetchTemplate(this.template, function(tmpl) {
        view.el.innerHTML = tmpl();

        done(view.el);
      });
    }
  });

})(namespace.module("customer"));
